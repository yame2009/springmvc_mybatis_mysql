/* 
 * Copyright (c) 2015, S.F. Express Inc. All rights reserved.
 */
package com.hb.netty.bookticket;

import java.io.Serializable;

/**
 * 描述：
 * 
 * <pre>HISTORY
 * ****************************************************************************
 *  ID   DATE           PERSON          REASON
 *  1    2015年3月10日      338342         Create
 * ****************************************************************************
 * </pre>
 * @author 338342
 * @since 1.0
 */
public class User implements Serializable{
	
	/**  */
	private static final long serialVersionUID = 6860730653789622363L;

	private String userName;
	
	private String phone;
	
	private String email;
	
	private String userId;

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}
	
	

}
