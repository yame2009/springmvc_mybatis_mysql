/* 
 * Copyright (c) 2015, S.F. Express Inc. All rights reserved.
 */
package com.hb.netty.bookticket;

/**
 * 描述： 指令集
 * 
 * <pre>HISTORY
 * ****************************************************************************
 *  ID   DATE           PERSON          REASON
 *  1    2015年3月10日      338342         Create
 * ****************************************************************************
 * </pre>
 * @author 338342
 * @since 1.0
 */
public class Code {
    public static final int CODE_SEARCH=1;//查询车票余量
    public static final int CODE_BOOK=2;//订票
    public static final int CODE_NONE=-1;//错误指令 无法处理
}
