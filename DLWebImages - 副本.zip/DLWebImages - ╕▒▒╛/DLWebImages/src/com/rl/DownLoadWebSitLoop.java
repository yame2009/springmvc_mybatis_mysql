package com.rl;

import java.util.HashSet;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class DownLoadWebSitLoop {

	
    public String webEncoding = "GBK";
//    public String webEncoding = "UTF-8";
    
    public String saveBasePath = "D:/demo";
    
    public int maxDepth = 10;
    
    public Set<String> webs = new HashSet<String>();

	public void doownLoad(String webSite){
		webs.clear();
		if(webSite!=null||"".equals(webSite)){
			doownLoadLoop(webSite,webEncoding,1);
		}
		webs.clear();
	}
	
	
	public void doownLoadLoop(String webSite,String webEncoding,int depth)
    {
		if(webs.contains(webSite)||webSite.contains("$")||webSite.contains(".zip")||webSite.contains("javascript:")||webSite.contains("??")||webSite.contains("/?/?")||webSite.contains("///")||webSite.contains("?/")){
			return;
		}
		webs.add(webSite);
		System.err.println("--------->下载第"+webs.size()+"个网页【"+webSite+"】<---------");
		DownLoadPicFromOneWebSite downLoader = new DownLoadPicFromOneWebSite();
		//下载本网页
		String html = downLoader.startDownload(webSite,webEncoding,saveBasePath);
		if(depth == maxDepth){
			return;
		}
		//查找子网页
		depth +=1;
		String regx = "<a href=\".*>";
		String head = "href=\"";
        Pattern pattern=Pattern.compile(regx);//新建一个正则表达式
        Matcher matcher=pattern.matcher(html);//对网页源代码进行查找匹配
        while(matcher.find())//对符合条件的结果逐条做处理
        {
            Matcher matcherNew=Pattern.compile(head+".*\"").matcher(matcher.group());
            if(matcherNew.find())
            {
                //<a href='/html/2/haizeiwang701.shtml' title="第701话 爱与激情与玩具之国的冒险" target='_blank'>第701话 爱与激情与玩具之国的冒险</a>
                String myUrl=matcherNew.group();
                myUrl=myUrl.replaceAll(head, "");//去掉前面的头部，如：href="
                myUrl=myUrl.substring(0,myUrl.indexOf("\""));//从第一个引号开始截取真正的内容，如：/html/2/haizeiwang701.shtml
                myUrl=WebSiteDownLoadUtil.joinUrlPath(webSite, myUrl);//得到最终的资源文件URL，如：http://www.manmankan.com/html/2/haizeiwang701.shtml
                if(myUrl!=null&&!"".equals(myUrl)){
                	doownLoadLoop(myUrl,webEncoding,depth);
                }
            }
        }
    }
}
