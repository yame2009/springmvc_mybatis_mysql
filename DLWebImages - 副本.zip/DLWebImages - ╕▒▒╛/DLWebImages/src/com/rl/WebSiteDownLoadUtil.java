package com.rl;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class WebSiteDownLoadUtil {

	 /**
     * 根据指定的URL下载html代码
     * @param pageURL 网页的地址
     * @param encoding 编码方式
     * @return 返回网页的html内容
     */
    public static String getHTML(String pageURL, String encoding) 
    {
        StringBuffer pageHTML = new StringBuffer();
        try 
        {
            URL url = new URL(pageURL);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestProperty("User-Agent", "MSIE 9.0");//设置客户的浏览器为IE9
//            connection.setConnectTimeout(10000);
            BufferedReader br = new BufferedReader(new InputStreamReader(connection.getInputStream(), encoding));
            String line = null;
            while ((line = br.readLine()) != null)
            {
                pageHTML.append(line);
                pageHTML.append("\r\n");
            }
            connection.disconnect();
        } 
        catch (Exception e) 
        {
            e.printStackTrace();
        }
        return pageHTML.toString();
    }
    
    /**
     * 获取URL中最后面的真实文件名
     * @param url 如：http://www.hua.com/bg.jpg
     * @return 返回bg.jpg
     */
    public static String getUrlFileName(String url)
    {
        return url.split("/")[url.split("/").length-1];
    }
    
    /**
     * 拼接URL路径和文件名，注意：以../或者/开头的fileName都要退一层目录
     * @param url 如：http://www.hua.com/product/9010753.html
     * @param fileName 如：../skins/default/css/base.css
     * @return http://www.hua.com/skins/default/css/base.css
     */
    public static String joinUrlPath(String url,String fileName)
    {
        //System.out.println("url:"+url);
        //System.out.println("fileName:"+fileName);
        if(fileName.startsWith("http://")||fileName.startsWith("https://"))
            return fileName;
        //如果去掉“http://”前缀后还包含“/”符，说明要退一层目录，即去掉当前文件名
        if(url.replaceAll("http://","").contains("/"))
            url=getUrlPath(url);
        if(fileName.startsWith("../")||fileName.startsWith("/"))
        {
            //只有当前URL包含多层目录才能后退，如果只是http://www.hua.com，想后退都不行
            if(url.replaceAll("http://","").contains("/"))
                url=getUrlPath(url);
            fileName=fileName.substring(fileName.indexOf("/")+1);
        }
        //System.out.println("return:"+url+"/"+fileName);
        return url+"/"+fileName;
    }
    
    /**
     * 获取URL不带文件名的路径
     * @param url 如：http://www.hua.com/bg.jpg
     * @return 返回 http://www.hua.com
     */
    public static String getUrlPath(String url)
    {
        return url.replaceAll("/"+ WebSiteDownLoadUtil.getUrlFileName(url), "");
    }
    
    /**
     * 根据URL下载某个文件
     * @param fileURL 下载地址
     * @param filePath 存放的路径
     */
    public static int downloadFile(String fileURL,String filePath) 
    {
        try
        {
            File file=new File(filePath);
            if(file.exists()){
            	return 0;
            }
            file.createNewFile();
            URL url = new URL(fileURL);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestProperty("User-Agent", "MSIE 9.0");//设置客户的浏览器为IE9
            byte[] buffer = new byte[1024];
            InputStream is = connection.getInputStream();
            FileOutputStream fos = new FileOutputStream(file);
            int len = 0;
            while ((len = is.read(buffer)) != -1)
                fos.write(buffer, 0, len);
            fos.close();
            is.close();
            connection.disconnect();
            return 1;
        }
        catch (IOException e)
        {
            System.out.println("该文件不存在或下载失败："+fileURL);
            return -1;
        }

    }
    /**
     * 读取某个文本文件的内容
     * @param file 要读取的文件
     * @param encode 读取文件的编码方式
     * @return 返回读取到的内容
     */
    public static String readFile(File file,String encode)
    {
        try
        {
            InputStreamReader read = new InputStreamReader (new FileInputStream(file),encode); 
            BufferedReader bufread=new BufferedReader(read);   
            StringBuffer sb=new StringBuffer();
            String str="";
            while ((str = bufread.readLine()) != null) 
                sb.append(str+"\n");
            String txt=new String(sb);
            return txt;
        }
        catch (Exception e)
        {
            e.printStackTrace();
            return null;
        }
    }

}
