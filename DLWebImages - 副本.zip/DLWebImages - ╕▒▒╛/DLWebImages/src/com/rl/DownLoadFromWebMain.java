package com.rl;

public class DownLoadFromWebMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		String webSite = "http://me2-sex.lofter.com/tag/美女摄影?page=1";
//		String webSite = "http://70.86.24.118:6666/index.php";
//		String webSite = "http://70.86.24.118:6666/forumdisplay.php?fid=5";
		DownLoadWebSitLoop downLoader = new DownLoadWebSitLoop();
		downLoader.doownLoad(webSite);
	}

}
