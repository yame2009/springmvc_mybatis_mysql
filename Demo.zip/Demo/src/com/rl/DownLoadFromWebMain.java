package com.rl;

public class DownLoadFromWebMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		String webSite = "http://www.manmankan.com";
		DownLoadWebSitLoop downLoader = new DownLoadWebSitLoop();
		downLoader.doownLoad(webSite);
		
//		webSite = webSite.replaceAll("(:|/)", ".");
//		System.out.println(webSite);
	}

}
