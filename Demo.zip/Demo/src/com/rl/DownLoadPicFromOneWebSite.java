package com.rl;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class DownLoadPicFromOneWebSite {

	
	public String html="";//存放网页HTML源代码
    public int cssCount=0;//下载成功的样式表文件个数
    public int jsCount=0;//下载成功的JavaScript文件个数
    public int normalImageCount=0;//普通图片数量
    public int backgroundImageCount=0;//背景图片数量
    
    public String webEncoding = "GBK";
    public String saveBasePath = "D:/Demo";
    public String cssPath = "css";
    public String jsPath ="js";
    public String imagesPath = "images";
    
    public boolean isDLCss = true;
    public boolean isDLJs = true;
    public boolean isDLImages = true;
    
    /**
     * 开始下载
     * @param targetWebSite 
     * @param saveBasePath 
     * @param webEncoding 
     * @return 返回本网页的HTML源码
     */
    public String startDownload(String targetWebSite, String webEncoding, String saveBasePath)
    {
    	initCache();
    	this.webEncoding =webEncoding;
    	this.saveBasePath = saveBasePath;
        File savePath=new File(saveBasePath);
        //计数清零
        cssCount=0;
        jsCount=0;
        normalImageCount=0;
        backgroundImageCount=0;
        
        //创建必要的一些文件夹
        if(!savePath.exists())
            savePath.mkdir();//如果文件夹不存在，则创建
        File css=new File(savePath+"/"+cssPath);
        File js=new File(savePath+"/"+jsPath);
        File images=new File(savePath+"/"+imagesPath);
        if(!css.exists())
        {
            css.mkdir();
            System.out.println("css文件夹不存在，已创建！");
        }
        if(!js.exists())
        {
            js.mkdir();
            System.out.println("js文件夹不存在，已创建！");
        }
        if(!images.exists())
        {
            images.mkdir();
            System.out.println("images文件夹不存在，已创建！");
        }
        
        //下载网页html代码
        System.out.println("开始下载【"+targetWebSite+"】网页HTML源代码！");
        html=WebSiteDownLoadUtil.getHTML(targetWebSite, webEncoding);
        System.out.println("网页HTML下载成功:");
        System.out.println("--------------------------------------------------");
        System.out.println(html);
        System.out.println("==================================================");
        
        
        
        if(isDLCss)
        {
            System.out.println("开始下载样式表文件！");
            regx("<link.*type=\"text/css\".*>", "href=\"", targetWebSite,cssPath);
        }
        if(isDLJs)
        {
            System.out.println("开始下载JavaScript文件！");
            regx("<script.*javascript.*>", "src=\"", targetWebSite, jsPath);
        }
        if(isDLImages)
        {
            System.out.println("开始下载网页前景图片文件！");
            regx("<img.*src.*>", "src=\"", targetWebSite, imagesPath);
        }
        
        //保存网页HTML到文件
        try
        {
            File newFile=new File(savePath.toString()+"/"+targetWebSite.replaceAll("(:|/)", "."));
            newFile.createNewFile();
            OutputStreamWriter writer=new OutputStreamWriter(new FileOutputStream(newFile), webEncoding);
            BufferedWriter bw=new BufferedWriter(writer);
            bw.write(html);
            bw.close();
            writer.close();
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
        String result="恭喜，【"+targetWebSite+"】网页的全部资源下载完毕！";
        result+="累计下载css文件"+cssCount+"个；\n";
        result+="累计下载JavaScript文件"+jsCount+"个；\n";
        result+="累计下载前景图片"+normalImageCount+"张；\n";
        result+="累计下载背景图片"+backgroundImageCount+"张。\n";
        System.out.println(result);
        System.out.println("==========================================");
        return html;
    }
    
    /**
     * 最核心的代码，从网页html中查找符合条件的图片、css、js等文件并批量下载
     * @param regx 检索内容的一级正则表达式，结果是含开始、结束标签的整个字符串，例如：<script.*javascript.*>
     * @param head 已经检索出的标签块中要提取的字符的头部，包含前面的双引号，如：src="
     * @param url 要下载的网页完整地址，如：http://www.hua.com
     * @param folderName 文件夹名，如：css
     */
    public void regx(String regx,String head,String url,String folderName)
    {
        //下载某种资源文件
        Pattern pattern=Pattern.compile(regx);//新建一个正则表达式
        Matcher matcher=pattern.matcher(html);//对网页源代码进行查找匹配
        while(matcher.find())//对符合条件的结果逐条做处理
        {
            Matcher matcherNew=Pattern.compile(head+".*\"").matcher(matcher.group());
            if(matcherNew.find())
            {
                //对于CSS匹配，查找出的结果形如：href="skins/default/css/base.css" rel="stylesheet" type="text/css"
                String myUrl=matcherNew.group();
                myUrl=myUrl.replaceAll(head, "");//去掉前面的头部，如：href="
                myUrl=myUrl.substring(0,myUrl.indexOf("\""));//从第一个引号开始截取真正的内容，如：skins/default/css/base.css
                
                String myName=WebSiteDownLoadUtil.getUrlFileName(myUrl);//获取样式表文件的文件名，如：base.css
                html=html.replaceAll(myUrl, folderName+"/"+myName);//替换html文件中的资源文件
                myUrl=WebSiteDownLoadUtil.joinUrlPath(url, myUrl);//得到最终的资源文件URL，如：http://www.hua.com/skins/default/css/base.css
                //System.out.println("发生地健康："+myUrl);
                //去掉文件名不合法的情况，不合法的文件名字符还有好几个，这里只随便举例几个
                if(!myName.contains("?")&&!myName.contains("\"")&&!myName.contains("/"))
                {    
                	WebSiteDownLoadUtil.downloadFile(myUrl, saveBasePath+"/"+folderName+"/"+myName);//开始下载文件
                    System.out.println("成功下载文件："+myName);
                    
                    if(regx.startsWith("<img"))//如果是下载前景图片文件
                        normalImageCount++;
                    if(regx.startsWith("<script"))//如果是下载JS文件
                        jsCount++;
                    if(regx.startsWith("<link"))//如果是下载css文件
                    {
                        cssCount++;
                        //将刚刚下载的CSS文件实例化
                        File cssFile=new File(saveBasePath+"/"+folderName+"/"+myName);
                        String txt=WebSiteDownLoadUtil.readFile(cssFile,"gb2312");//读取CSS文件的内容，这里用默认的gb2312编码
                        //开始匹配背景图片
                        Matcher matcherUrl=Pattern.compile("background:url\\(.*\\)").matcher(txt);
                        while (matcherUrl.find())
                        {
                            //去掉前面和后面的标记,得到的结果如：../images/ico_4.gif
                            String temp=matcherUrl.group().replaceAll("background:url\\(", "").replaceAll("\\)", "");
                            //拼接出真正的图片路径，如：http://www.hua.com/skins/default/images/ico_4.gif
                            String backgroundUrl=WebSiteDownLoadUtil.joinUrlPath(myUrl, temp);
                            //获取背景图片的文件名，如：ico_4.gif
                            String backgroundFileName=WebSiteDownLoadUtil.getUrlFileName(backgroundUrl);
                            //背景图片要保存的路径，如：c:/users\lxa\desktop\网页\images\ico_4.gif
                            String backgroundFilePath=saveBasePath+"/"+imagesPath+"/"+backgroundFileName;
                            if(!new File(backgroundFilePath).exists())//如果不存在同名文件
                            {    
                                if(WebSiteDownLoadUtil.downloadFile(backgroundUrl, backgroundFilePath))//开始下载背景图片
                                {
                                    backgroundImageCount++;//计数加1
                                    System.out.println("成功下载背景图片："+backgroundFileName);
                                }
                            }
                            else
                            {
                                System.out.println("指定文件夹已存在同名文件，已为您自动跳过："+backgroundFilePath);
                            }
                        }
                    }
                    
                }
            }
        }
    }
    
   public void initCache(){
		html="";
	    cssCount=0;
	    jsCount=0;
	    normalImageCount=0;
	    backgroundImageCount=0;
   }
}
