package com.rl;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class DownLoadWebSitLoop {

	
    public String webEncoding = "GBK";
    
    public String saveBasePath = "D:/Demo";

	public void doownLoad(String webSite){
		
		doownLoadLoop("<a href=\".*>", "href=\"", webSite,webEncoding);
	}
	
	
	public void doownLoadLoop(String regx,String head,String webSite,String webEncoding)
    {
		DownLoadPicFromOneWebSite downLoader = new DownLoadPicFromOneWebSite();
		//下载本网页
		String html = downLoader.startDownload(webSite,webEncoding,saveBasePath);
		//查找子网页
        Pattern pattern=Pattern.compile(regx);//新建一个正则表达式
        Matcher matcher=pattern.matcher(html);//对网页源代码进行查找匹配
        while(matcher.find())//对符合条件的结果逐条做处理
        {
            Matcher matcherNew=Pattern.compile(head+".*\"").matcher(matcher.group());
            if(matcherNew.find())
            {
                //<a href='/html/2/haizeiwang701.shtml' title="第701话 爱与激情与玩具之国的冒险" target='_blank'>第701话 爱与激情与玩具之国的冒险</a>
                String myUrl=matcherNew.group();
                myUrl=myUrl.replaceAll(head, "");//去掉前面的头部，如：href="
                myUrl=myUrl.substring(0,myUrl.indexOf("\""));//从第一个引号开始截取真正的内容，如：/html/2/haizeiwang701.shtml
                myUrl=WebSiteDownLoadUtil.joinUrlPath(webSite, myUrl);//得到最终的资源文件URL，如：http://www.manmankan.com/html/2/haizeiwang701.shtml
                downLoader.startDownload(myUrl,webEncoding,saveBasePath);
            }
        }
    }
}
